package com.example.trocaia;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.OpenableColumns;import android.view.*;import android.widget.*;

public class MainActivity extends Activity {
    Button videoButton, avatarButton, processButton, exportButton; TextView videoName, avatarName, status; ProgressBar progress; Uri videoUri, avatarUri;
    static final int VIDEO=10, AVATAR=11;
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
        videoButton=findViewById(R.id.videoButton); avatarButton=findViewById(R.id.avatarButton); processButton=findViewById(R.id.processButton); exportButton=findViewById(R.id.exportButton); videoName=findViewById(R.id.videoName); avatarName=findViewById(R.id.avatarName); status=findViewById(R.id.status); progress=findViewById(R.id.progress);
        videoButton.setOnClickListener(v->pick(VIDEO)); avatarButton.setOnClickListener(v->pick(AVATAR)); processButton.setOnClickListener(v->process()); exportButton.setOnClickListener(v->save()); }
    void pick(int type){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(type==VIDEO?"video/*":"image/*"); startActivityForResult(i,type); }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(c!=RESULT_OK||d==null)return; if(r==VIDEO){videoUri=d.getData();videoName.setText("Vídeo: "+name(videoUri));}else{avatarUri=d.getData();avatarName.setText("Avatar: "+name(avatarUri));} processButton.setEnabled(videoUri!=null&&avatarUri!=null);}
    String name(Uri u){String n=null; try(Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(x>=0)n=c.getString(x);}}catch(Exception ignored){} return n==null?u.toString():n;}
    void process(){progress.setVisibility(View.VISIBLE);processButton.setEnabled(false);status.setText("Preparando vídeo e avatar…"); new Handler().postDelayed(()->{progress.setVisibility(View.GONE);status.setText("Projeto preparado. Conecte um motor de IA de troca autorizada no módulo de processamento para gerar o vídeo final.");exportButton.setEnabled(false);processButton.setEnabled(true);},1200);}
    void save(){Toast.makeText(this,"Resultado pronto para exportação quando o motor de IA estiver conectado.",Toast.LENGTH_LONG).show();}
}
