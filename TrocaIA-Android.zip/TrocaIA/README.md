# TrocaIA — Android

App Android de edição de vídeo com seleção de vídeo + avatar/personagem autorizado.

## Abrir
1. Instale o Android Studio.
2. Abra esta pasta como projeto.
3. Aguarde a sincronização do Gradle.
4. Execute em um celular Android ou emulador.

## IA
A interface já está preparada para receber um motor de IA. A função de troca deve ser usada apenas com pessoas/personagens para os quais você tenha autorização. O processamento pode ser implementado como serviço local ou API própria.
